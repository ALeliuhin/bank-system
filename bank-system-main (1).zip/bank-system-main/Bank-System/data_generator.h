#pragma once

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define IBAN_LENGTH 24
void generate_random_iban(char *iban);